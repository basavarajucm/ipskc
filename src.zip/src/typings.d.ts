/* SystemJS module definition */
declare var module: NodeModule;
declare var mycodova: any;
interface NodeModule {
  id: string;
}
