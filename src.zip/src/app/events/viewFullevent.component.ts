import { Component, OnInit } from '@angular/core';
import {Router,ActivatedRoute } from '@angular/router';
import { EventsService} from './events.service';

@Component({
  selector: 'app-fullEvents',
  templateUrl: './viewFullevent.component.html',
  styleUrls: ['./viewFullevent.component.css']
})
export class viewFulleventComponent implements OnInit
{
    id:number;
    constructor(private router:Router,private activate:ActivatedRoute,  private eventService:EventsService)
    {

    }
    events(url:any){
       // console.log(url);
        new mycodova(url);
      }
    goBack()
    {
        this.router.navigate(['events']);
    }
    eventTitle:string;
    eventDescription:string;
    isResponse:boolean=false;
    ngOnInit(){
        this.activate.params.subscribe(params=>{
            this.id=params.id;
            this.eventService.getEventDesc(this.id)
            . map((data) => data.json())
            .subscribe(
              data=>
              {
               //console.log(data);
               this.eventTitle=data.eventTitle;
               this.eventDescription=data.eventDescription;
               this.isResponse=true;
               
             });  
            
            
          

        });

    }
}