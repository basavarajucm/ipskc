import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';

@Injectable()
export class EventsService {

  constructor(private http:Http)
  {

  }
    getData(id:number)
    {
            return this.http.post("http://localhost/ipskc/events/getdata",JSON.stringify(id))
    }
    getEventDesc(eventId:number)
    {
      return this.http.post("http://localhost/ipskc/events/getEventDetails",JSON.stringify(eventId))
    }

   

}
