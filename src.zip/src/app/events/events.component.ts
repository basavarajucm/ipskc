import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventsService} from './events.service';


@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css']
})
export class EventsComponent implements OnInit {
  selectedValue: string;
  events = [
    {value: 'Day', viewValue: 'Day'},
    {value: 'Month', viewValue: 'Month'},
    {value: 'Year', viewValue: 'Year'}
  ];


  constructor(private router:Router, private eventService:EventsService ) { }

  viewMore(id:number)
  {
    console.log(id);
    this.router.navigate(['viewFullevent',{id:id}]);
  }
  today: number = Date.now();

// viewDetail=[
//              {title:'IPSKC State Level UG Psychiatry Quiz 2018',
//              content:'Indian Psychiatry Society-Karnataka Chapter (IPS-KC) has been conducting State Level compitation 2018'},
//             {title:'IPSKC State Level UG Psychiatry Quiz 2019',
//             content:'Indian Psychiatry Society-Karnataka Chapter (IPS-KC) has been conducting State Level compitation 2019'},
//             {title:'IPSKC State Level UG Psychiatry Quiz 2020',
//             content:'Indian Psychiatry Society-Karnataka Chapter (IPS-KC) has been conducting State Level compitation 2020'}
//            ];


currentUser:string;
id:number;
responseData:Object;
isResponse:boolean;
eventTitle=[];

  ngOnInit() {
    this.currentUser=JSON.parse(localStorage.getItem('logindata'));
    //console.log(this.currentUser['userid']);
     this.id=this.currentUser['userid'];
    this.eventService.getData(this.id)
    . map((data) => data.json())
    .subscribe(
      data=>
      {
       //console.log(data);
        this.responseData=data;
        //console.log(this.responseData);
        this.isResponse=true;        


     
      });  
    
  }



}
/*export class viewDetail{

  constructor(public title:string,public content:[])
  {

  }
  

} */
