import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'appheader',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  title = 'Indian Psychiatric Society Karnataka Chapter';
  constructor() { }
  public currentUser:string;
  name:string;
  changeIconColor:string;

  /*changeColor(e)
  {
    console.log(e);
    this.changeIconColor='red';
  }*/
  ngOnInit() {
    this.currentUser=JSON.parse(localStorage.getItem('logindata'));
   // console.log(this.currentUser['name']);
    this.name=this.currentUser['name'];
  }
  
  
}
