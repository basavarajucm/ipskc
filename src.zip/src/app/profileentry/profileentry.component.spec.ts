import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileentryComponent } from './profileentry.component';

describe('ProfileentryComponent', () => {
  let component: ProfileentryComponent;
  let fixture: ComponentFixture<ProfileentryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProfileentryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProfileentryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
