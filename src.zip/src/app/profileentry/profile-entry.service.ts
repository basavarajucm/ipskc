import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';

@Injectable()
export class ProfileEntryService {

  constructor(private http:Http) { }

  savedata(qualification:string,workedat:string,workedas:string,id:string)
  {
   /*return this.http.post("http://localhost/ipskc/file/save_profile_data",JSON.stringify({qualification:qualification,workedat:workedat,workedas:workedas}))
    .map((response:Response)=>response.json());*/


    return this.http.post("http://localhost/ipskc/file/save_profile_data",JSON.stringify({qualification:qualification,workedat:workedat,workedas:workedas,id}))
    .map((response:Response)=>response.json());
   
  }

}
