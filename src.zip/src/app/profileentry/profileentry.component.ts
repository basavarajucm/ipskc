import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {Router } from '@angular/router';
import { Http,Response } from '@angular/http';
import {ProfileEntryService} from './profile-entry.service';
import {FormControl} from '@angular/forms';
import {Observable} from 'rxjs/Observable';
import {startWith} from 'rxjs/operators/startWith';
import 'rxjs/add/operator/map';
import {map} from 'rxjs/operators/map';


// export class qualification
// {
  
//   constructor(public qualification:string)
//   {

//   }
// }
export class workedAt
{
  constructor(public workedAt:string)
  {

  }
}
export class workedAs
{
  constructor(public workedAs:string)
  {

  }
}


@Component({
  selector: 'app-profileentry',
  templateUrl: './profileentry.component.html',
  styleUrls: ['./profileentry.component.css']
})
export class ProfileentryComponent implements OnInit {

  title = 'Indian Psychiatric Society Karnataka Chapter';
  
  options: FormGroup;
  currentUser:string;
  name:string;
  dob:string;
  id:string;
  status:string;

  toppings = new FormControl();
  toppingList = ['MBBS', 'PHD', 'DNB', 'BSc(speech and hearing)'];
  
  // qualificatnCtrl: FormControl;
  // filteredQualificatn: Observable<any[]>;

  workedAtCntrl:FormControl;
  filteredWorkedAt:Observable<any[]>;

  workedAsCntrl:FormControl;
  filteredWorkedAs:Observable<any[]>;

  workingAt:workedAt[]=[
   {
    workedAt:'JSS hospital'
   },
   {
    workedAt:'BGS hospital'
   },
   {
    workedAt:'CITY hospital'
   }
];

workingAs:workedAs[]=[
  {
   workedAs:'Dermatologist'
  },
  {
   workedAs:'physiothraphyst'
  },
  {
   workedAs:'heart specialist'
  }
];
  // qualifications:qualification[]=[
  //   {
  //     qualification:'MBBS'
  //   },
  //   {
  //     qualification:'MD'
  //   },
  //   {
  //     qualification:'PHD'
  //   }

  // ];

 constructor(private router:Router, private http:Http,private profile:ProfileEntryService,fb: FormBuilder) 
 { 
      this.options = fb.group({
       floatLabel: 'never',
    });
    // this.qualificatnCtrl=new FormControl();
    // this.filteredQualificatn=this.qualificatnCtrl.valueChanges
    // .pipe(
    //   startWith(''),
    //   map(qualification => qualification ? this.filterQualificatn(qualification) : this.qualifications.slice())
    // );
    this.workedAtCntrl=new FormControl();
    this.filteredWorkedAt=this.workedAtCntrl.valueChanges
    .pipe(
      startWith(''),
      map(workedat => workedat ? this.filterWorkedAt(workedat) : this.workingAt.slice())

    );

    this.workedAsCntrl=new FormControl();
    this.filteredWorkedAs=this.workedAsCntrl.valueChanges
    .pipe(
      startWith(''),
      map(workedas => workedas ? this.filterWorkedAs(workedas) : this.workingAs.slice())

    );
 }
 filterWorkedAt(workedAt:string)
 {
   return this.workingAt.filter(working=>
     working.workedAt.toLowerCase().indexOf(workedAt.toLowerCase())== 0);
 }
 filterWorkedAs(workedAs:string)
 {
   return this.workingAs.filter(working=>
     working.workedAs.toLowerCase().indexOf(workedAs.toLowerCase())== 0);
 }
//  filterQualificatn(qualification:string)
//  {
//   return this.qualifications.filter(qualifi =>
//   qualifi.qualification.toLowerCase().indexOf(qualification.toLowerCase()) === 0);
//  }

 


  onfileselected(e)
  {
    e.preventDefault();
   let elem= e.target;
    if(elem.files.length > 0)
    {
      //console.log(elem.files[0]);
      let formData =new FormData();
     // console.log(this.id);
      formData.append('file' ,elem.files[0]);
      formData.append('id' ,this.id);
       console.log(formData);
     
    
 /* this.http.post("http://localhost/ipskc/file/save_profile_image",formData)
  .map((response:Response)=>response.json())
  .subscribe((data)=>{
                      this.status=data.status;
                      
                      
						}, (error) => {
							console.log('error')
            });*/
            
   return Observable.of(JSON.stringify({"status":"file uploaded successfully"}))
    .map((data) => data)
    .subscribe(
    data => { 
          console.log(data);
          this.status =JSON.parse(data).status;
          console.log(this.status);
     });        
	}
  }
  selectedOption: string;
  saveProfileData(e)
  {
    //e.preventDefault();
   var qualification=this.selectedOption;
    var worked_at=e.target.workedat.value;
    var worked_as=e.target.workedas.value;
    console.log(qualification);
    console.log(worked_at);
    console.log(worked_as);
	/*this.profile.savedata(qualification,worked_at,worked_as,this.id)
 .subscribe( 
           data=>{localStorage.setItem('profile',JSON.stringify(data));
           console.log(data);
           this.status= data.status;
           if(this.status == "success")
           {
            this.router.navigate(['HomePage']);
           }

           
  });*/
  return Observable.of(JSON.stringify({"status":"success"}))
    .map((data) => data)
    .subscribe(
    data => { 
          console.log(data);
          this.status =JSON.parse(data).status;
          console.log(this.status);
          if(this.status == "success")
          {
            this.router.navigate(['HomePage']);
          }
     });  
  }

  ngOnInit() {
    this.currentUser=JSON.parse(localStorage.getItem('logindata'));
   // console.log(this.currentUser['name']);
    this.name=this.currentUser['name'];
    this.dob=this.currentUser['birthdate'];
    this.id=this.currentUser['userid'];
   
  }

}
