import { TestBed, inject } from '@angular/core/testing';

import { ProfileEntryService } from './profile-entry.service';

describe('ProfileEntryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ProfileEntryService]
    });
  });

  it('should be created', inject([ProfileEntryService], (service: ProfileEntryService) => {
    expect(service).toBeTruthy();
  }));
});
