import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  emailFormControl = new FormControl('', [
    Validators.required,
    Validators.email,
  ]);
  nameFormControl =new FormControl('', [
    Validators.required,

  ]);
  commentFormControl =new FormControl('', [
    Validators.required,

  ]);
   status:string;
  constructor(private http:Http) { }

  saveReview(e)
  {

    var name= e.target.uname.value;
    var email= e.target.email.value;
    var cmnt = e.target.comment.value;
    /*this.http.post("http://localhost/ipskc/file/saveReview",JSON.stringify({name:name,email:email,cmnt:cmnt}))
    .map((response:Response)=>response.json())
    .subscribe(
      data => {
            
           console.log(data);
        }

    );*/
    return Observable.of(JSON.stringify({"status":"Thanks for your valuable Reviews"}))
    .map((data) => data)
    .subscribe(
      data => {
            
           //console.log(data);
           JSON.parse(data);
           //console.log(JSON.parse(data));
           this.status=JSON.parse(data).status;
           
        }

    );
  }
  

  
  ngOnInit() {
  }

}
