import { Injectable } from '@angular/core';
import { Http,Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';

@Injectable()
export class officeBearers {
    name=[];
    designation=[];
    workedat=[];
    workedas=[];
    imagepath=[];
    getData()
    {
       return Observable.of(JSON.stringify([{"name": "President", "designation":"Dr Abhay Matkar","workedAt":"SRI RAM HOSPITAL","workedAs":"Cardiologist", "imagePath":"./assets/icons/1.JPG"},
                                            { "name": "President", "designation":"Dr Abhay Matkar","workedAt":"SRI RAM HOSPITAL","workedAs":"Cardiologist", "imagePath":"./assets/icons/1.JPG"},
                                             { "name": "President", "designation":"Dr Abhay Matkar","workedAt":"SRI RAM HOSPITAL","workedAs":"Cardiologist", "imagePath":"./assets/icons/1.JPG" }]))
        
    }
}
