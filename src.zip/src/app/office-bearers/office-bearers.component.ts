import { Component, OnInit, ViewChild } from '@angular/core';
import {MatTableDataSource, MatSort} from '@angular/material';
import {officeBearers} from './officeBearers.service';

@Component({
  selector: 'app-office-bearers',
  templateUrl: './office-bearers.component.html',
  styleUrls: ['./office-bearers.component.css']
})
export class OfficeBearersComponent{
 
  constructor(private officeBearers:officeBearers) {

   }
 

  //   Element = [
  //   {position: 1, name: 'President', designation:'Dr Abhay Matkar',workedAt:'SRI RAM HOSPITAL',workedAs:'Cardiologist', imagePath:'./assets/icons/1.JPG'},
  //   {position: 2, name: 'President Elect',designation:'Dr Chandrashekar H',workedAt:'The Bangalore Hospital',workedAs:'Dermatologist',imagePath:'./assets/icons/2.JPG'},
  //   {position: 3, name: 'Honorary Secretary',designation:'Dr Hemanth Kumar B G',workedAt:'Republic Hospital',workedAs:'Gastroenterologist',imagePath:'./assets/icons/3.JPG' },
  //   {position: 4, name: 'Honorary Treasurer',designation:'Dr Kiran Kumar P K',workedAt:'Bangalore Baptist Hospital',workedAs:'Nephrologist',imagePath:'./assets/icons/4.JPG' },
  //   {position: 5, name: 'Honorary Editor', designation:'Dr Kiran Kumar K',workedAt:'Church of South India Hospital',workedAs:'Neurologist',imagePath:'./assets/icons/5.JPG'},
  //   {position: 6, name: 'Immediate Past President',designation:'Dr Mahesh R Gowda',workedAt:'Axon Speciality Hospital',workedAs:'Gynecologist',imagePath:'./assets/icons/6.JPG' },
  //   {position: 7, name: 'Immediate Past Secretary',designation:'Dr Hemanth Kumar B G',workedAt:'Mahabodhi Mallige Hospital',workedAs:'Cardiologist',imagePath:'./assets/icons/7.JPG'},
  //   {position: 8, name: 'EC Member & Joint Secretary', designation:'Dr Sunilkumar G Patil'},
  //   {position: 10, name: 'EC Member',designation:'Dr Vijaykumar Harbishettar' }
  // ];
 
  
  
  

 getData=[];
 isResponse:boolean=false;

  ngOnInit() {
    this.officeBearers.getData()
    . map((data) => data)
    .subscribe(
      data=>
      {
        this.getData= JSON.parse(data);
        this.isResponse=true;
     
      });  
   
  }

}

