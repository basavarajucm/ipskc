import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { LoginserviceService } from './loginservice.service';
import {Router} from '@angular/router';

@Injectable()
export class AuthguardGuard implements CanActivate {
  constructor(private login:LoginserviceService,private router:Router){
     
  }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
     /* this.router.navigate(['/']);
    return this.login.getUserLoggedIn();*/
    if(localStorage.getItem('logindata') && localStorage.getItem('otp'))
    {
     this.router.navigate(['HomePage']);
      return true;
    }
   // this.router.navigate(['/']);
    return true;
  }
}
