import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
 import {Router} from '@angular/router';
import { Http,Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { LoginserviceService } from './loginservice.service';
import { loginDetails } from './login.model';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent {

  title = 'Indian Psychiatric Society Karnataka Chapter';
  //loginDetail:loginDetails;

  id:number;
  otp:number;
  status:string="failure";
  wrongOtp:boolean=false;
  clickresend:boolean;
  mobile:string;
 // data:Object;

  constructor(private router:Router, private http:Http,private login:LoginserviceService){
}
private flag=false;
private errormsg=false;
public loginuser(e)
{
  e.preventDefault();
  var dob =e.target.dob.value;
  var fname = e.target.fname.value;
  var mob = e.target.mobile_number.value;

  console.log(dob);
  console.log(fname);
  console.log(mob);
 /* this.login.getuser(dob,fname,mob)
.subscribe(
  data=>{localStorage.setItem('logindata',JSON.stringify(data));
    console.log(data);
   this.id=data.id;
    this.status=data.status;
    console.log(this.status);
    console.log(this.id);
 if(this.status == "failure")
    {
      this.errormsg=true;
    }
    
  });*/

  if(fname == "Basavaraju" || fname== "basavaraju" && dob=="4/19/1962" && mob=="9964976363")
  {
    return Observable.of(JSON.stringify({"id":28,"userid":"2","status":"success","name":"basavaraju","birthdate":"4/19/1962"}))
    .map((data) => data)
    .subscribe(
      data => {
             localStorage.setItem('logindata',data);
             // console.log(data);
             JSON.parse(data);
             console.log(JSON.parse(data));
           this.status=JSON.parse(data).status;
           
        }

    );

  }
  else
  {
    this.errormsg=!this.errormsg;
    this.flag=false;
  }

}
public getotp()
{
  this.flag=true;
  this.errormsg=false;
}
public validateotp(e)
{

  e.preventDefault();
  var otp =e.target.otp.value;
 /* this.login.authenticateuser(this.id,otp)
  .subscribe(
    data=>{
         console.log(data);
         this.status=data.status;
         console.log(this.status);
         if(this.status == "success")
         {
          this.login.setUserLoggedIn();
           this.router.navigate(['profileentry']);
         }
         else
         {
          this.router.navigate(['']);
          this.wrongOtp = true;
          this.clickresend=false;

         }

    });*/
    if(otp == "123456")
    {
      this.router.navigate(['profileentry']);
      localStorage.setItem('otp',otp);
    }
    else
    {
      this.router.navigate(['']);
      this.wrongOtp = true;
      this.clickresend=false;
    }
}
public resendotp()
{
  console.log("mobile"+this.mobile);
  console.log("id"+this.id);
  this.clickresend=true;
  this.wrongOtp = false;
 // this.login.resendotp(this.id,this.mobile)
 return Observable.of(JSON.stringify({"msg":"Message has been sent to your mobile number"}))
 .map((data) => data)
  .subscribe(
    data=>
    {
      console.log(data)
    });
}

}
