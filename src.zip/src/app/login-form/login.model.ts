export class loginDetails
{
    id:number;
    dob:string;
    name:string;
    ipskc:string;
    mobile:string;
    status:string;
}