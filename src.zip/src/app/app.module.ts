import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatButtonModule} from '@angular/material/button';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { MatNativeDateModule, MatInputModule} from '@angular/material';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginFormComponent } from './login-form/login-form.component';
import { HttpModule } from '@angular/http';
import {LoginserviceService} from './login-form/loginservice.service';
import {ProfileEntryService} from './profileentry/profile-entry.service';
import { HomePageComponent } from './home-page/home-page.component';
import {MatTabsModule} from '@angular/material/tabs';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule } from '@angular/material';
import {AuthguardGuard } from './login-form/authguard.guard';
import { HeaderComponent } from './header/header.component';
import { OfficeBearersComponent } from './office-bearers/office-bearers.component';
import { EventsComponent } from './events/events.component';
import { NotificationComponent } from './notification/notification.component';
import { ReachUsComponent } from './reach-us/reach-us.component';
import { FooterComponent } from './footer/footer.component';
import {MatToolbarModule} from '@angular/material/toolbar';
import { ProfileComponent } from './profile/profile.component';
import { ProfileentryComponent } from './profileentry/profileentry.component';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatCardModule} from '@angular/material/card';
import {MatDialogModule} from '@angular/material/dialog';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {viewFulleventComponent} from './events/viewFullevent.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatTableModule} from '@angular/material/table';
import {MatListModule} from '@angular/material/list';
import {DialogOverviewExampleDialog} from './profile/profile.component';
import {viewNotificationComponent} from './home-page/viewNotification.component'; 
import {DilogForSaveChanges} from './profile/profile.component';
import {DilogForChangeProfilePicture} from './profile/profile.component';
import {officeBearers} from './office-bearers/officeBearers.service';
import {EventsService} from './events/events.service';




const appRoutes:Routes = [
  {
    path:'',
    canActivate:[AuthguardGuard],
    component:LoginFormComponent
 },

  {
     path:'HomePage',
    // canActivate:[AuthguardGuard],
     component:HomePageComponent
  },
  {
    path:'officeBearers',
    //canActivate:[AuthguardGuard],
    component:OfficeBearersComponent
  },
  {
    path:'events',
    //canActivate:[AuthguardGuard],
    component:EventsComponent
  },
  {
    path:'notification',
    //canActivate:[AuthguardGuard],
    component:NotificationComponent
  },
  {
    path:'profile',
    //canActivate:[AuthguardGuard],
    component:ProfileComponent
  },
  {
    path:'profileentry',
    //canActivate:[AuthguardGuard],
    component:ProfileentryComponent
  },
  {
    path:'reachUs',
    //canActivate:[AuthguardGuard],
    component:ReachUsComponent
  },

 
  {
    path:'viewFullevent',
    component:viewFulleventComponent
  },
  {
    path:'viewNotification',
    component:viewNotificationComponent
  }

 ]


@NgModule({
  declarations: [
    AppComponent,
    LoginFormComponent,
    HomePageComponent,
    HeaderComponent,
    OfficeBearersComponent,
    EventsComponent,
    NotificationComponent,
    ReachUsComponent,
    FooterComponent,
    ProfileComponent,
    ProfileentryComponent,
    viewFulleventComponent,
    DialogOverviewExampleDialog,
    viewNotificationComponent,
    DilogForSaveChanges,
    DilogForChangeProfilePicture
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatCheckboxModule,
    BrowserAnimationsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTabsModule,
    MatMenuModule,
    MatIconModule,
    MatToolbarModule,
    MatAutocompleteModule,
    MatCardModule,
    MatDialogModule,
    MatTooltipModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    MatTableModule,
    MatListModule,
    HttpModule
],
  providers: [LoginserviceService,officeBearers,ProfileEntryService,AuthguardGuard,EventsService],
  entryComponents:[DialogOverviewExampleDialog,DilogForSaveChanges,DilogForChangeProfilePicture],
  bootstrap: [AppComponent]
})
export class AppModule { }
