import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reach-us',
  templateUrl: './reach-us.component.html',
  styleUrls: ['./reach-us.component.css']
})
export class ReachUsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
